﻿// Grading ID: C5105
// Program 2
// Due Date : 03/09/2017
// CIS 199-75
// This program is designed for UofL students to register for Fall 2017 courses using the registration schedule. 
// It gathers the first letter of the user's last name (from a textbox) and the user's class standing 
// (freshman, sophomore, junior, or senior) using a set of RadioButton controls. It also has a list box which 
// displays the registration time and date and a clear button to clear the content from the textbox and the list box.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Program2 : Form
    {
        string lastName; 
        char LastNameFirstInitial; 
        string dateToRegister; 
        string timeToRegister; 
        // variables to display the last name, first initial, registration date and time.

        public Program2()
        {
            InitializeComponent();
        }

        private void checkButton_Click(object sender, EventArgs e)
        {
            lastName = lastName_Tb.Text; // display last name in text box
            LastNameFirstInitial = lastName[0]; // considers only the first inital even if you write the last name 
            LastNameFirstInitial = char.ToUpper(LastNameFirstInitial); // it makes the lower case letter to the upper case, 
                                                                        // and can work for both upper and lower case 

            if(sophmore_Rb.Checked || freshmen_Rb.Checked) // displays the following time to register if the student is a sophmore 
                                                           // or a freshmen depending on their last name.
        {
                if (LastNameFirstInitial <= 'B')
                { timeToRegister = "4:00 PM"; } 

                else if (LastNameFirstInitial <= 'D')
                { timeToRegister = "8:30 AM"; } 

                else if (LastNameFirstInitial <='F')
                { timeToRegister = "10:00 AM"; } 

                else if (LastNameFirstInitial <='I') 
                { timeToRegister = "11:30 AM"; } 

                else if (LastNameFirstInitial <='L') 
                { timeToRegister = "2:00 PM"; } 

                else if (LastNameFirstInitial <='O') 
                { timeToRegister = "4:00 PM"; } 

                else if (LastNameFirstInitial <='Q') 
                { timeToRegister = "8:30 AM"; } 

                else if (LastNameFirstInitial <='S') 
                { timeToRegister = "10:00 AM"; } 

                else if (LastNameFirstInitial <= 'V') 
                { timeToRegister = "11:30 AM"; } 

                else if (LastNameFirstInitial <= 'Z') 
                { timeToRegister = "2:00 PM"; } 
            }

            if (freshmen_Rb.Checked) // displays the date to register for freshmens depending upon their last name.
                // students with last initials with A,B, and p-z registers on April 4th and C-O registers on the 5th April
            {
                if (LastNameFirstInitial >= 'C' || LastNameFirstInitial >= 'O')
                { dateToRegister = "Wednesday, April 5"; }

                if (LastNameFirstInitial <= 'B' || LastNameFirstInitial >= 'P')
                { dateToRegister = "Tuesday, April 4"; } 
            }

            if (sophmore_Rb.Checked) // displays the date to register for sophmmores depending upon their last name.
                // Students with last initials with A,B and P-Z can reister on March 31st and C-O registers on April 3rd  
            {
                if (LastNameFirstInitial >= 'C' || LastNameFirstInitial >= 'O')
                { dateToRegister = "Monday, April 3"; } 

                if (LastNameFirstInitial <= 'B' || LastNameFirstInitial >= 'P')
                { dateToRegister = "Friday, March 31"; } 
            }

            if (junor_Rb.Checked || senior_Rb.Checked) // displays the following time to register if the student is a junior or a 
                                                       // senior depending on their last name.
            {
                if (LastNameFirstInitial <='D') 
                    { timeToRegister = "11:30 AM"; } 

                else if (LastNameFirstInitial <='I') 
                    { timeToRegister = "2:00 PM"; } 

                else if (LastNameFirstInitial <= 'O') 
                    { timeToRegister = "4:00 PM"; } 

                else if (LastNameFirstInitial <= 'S') 
                    { timeToRegister = "8:30 AM"; } 

                else if (LastNameFirstInitial <='Z') 
                    { timeToRegister = "10:30 AM"; } 
            }

            if (junor_Rb.Checked) // displays the date to register for the juniors
            { dateToRegister = "Thursday, March 30" ; } 

            else if (senior_Rb.Checked) // displays the date to register for the seniors
            { dateToRegister = "Wednesday, March 29"; } 

            timeDate_Label.Text = dateToRegister + "" + "\n" + timeToRegister; 
            // displays date on the 1st line and time on the 2nd line

        }

        private void clear_Button_Click(object sender, EventArgs e)
        {
            timeDate_Label.Text = ""; // clears the time-date label
            lastName_Tb.Clear(); // clears the last name textbox
        }
    }
}
