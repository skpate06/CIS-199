﻿namespace Program_2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Program2));
            this.lastName_Label = new System.Windows.Forms.Label();
            this.lastName_Tb = new System.Windows.Forms.TextBox();
            this.classGroupBox = new System.Windows.Forms.GroupBox();
            this.senior_Rb = new System.Windows.Forms.RadioButton();
            this.junor_Rb = new System.Windows.Forms.RadioButton();
            this.sophmore_Rb = new System.Windows.Forms.RadioButton();
            this.freshmen_Rb = new System.Windows.Forms.RadioButton();
            this.check_Button = new System.Windows.Forms.Button();
            this.time_Label = new System.Windows.Forms.Label();
            this.timeDate_Label = new System.Windows.Forms.Label();
            this.clear_Button = new System.Windows.Forms.Button();
            this.classGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // lastName_Label
            // 
            this.lastName_Label.AutoSize = true;
            this.lastName_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastName_Label.Location = new System.Drawing.Point(28, 21);
            this.lastName_Label.Name = "lastName_Label";
            this.lastName_Label.Size = new System.Drawing.Size(142, 16);
            this.lastName_Label.TabIndex = 0;
            this.lastName_Label.Text = "Student Last Name:";
            // 
            // lastName_Tb
            // 
            this.lastName_Tb.Location = new System.Drawing.Point(31, 46);
            this.lastName_Tb.Name = "lastName_Tb";
            this.lastName_Tb.Size = new System.Drawing.Size(138, 20);
            this.lastName_Tb.TabIndex = 1;
            // 
            // classGroupBox
            // 
            this.classGroupBox.Controls.Add(this.senior_Rb);
            this.classGroupBox.Controls.Add(this.junor_Rb);
            this.classGroupBox.Controls.Add(this.sophmore_Rb);
            this.classGroupBox.Controls.Add(this.freshmen_Rb);
            this.classGroupBox.Location = new System.Drawing.Point(31, 89);
            this.classGroupBox.Name = "classGroupBox";
            this.classGroupBox.Size = new System.Drawing.Size(138, 163);
            this.classGroupBox.TabIndex = 2;
            this.classGroupBox.TabStop = false;
            this.classGroupBox.Text = "Class Standing:";
            // 
            // senior_Rb
            // 
            this.senior_Rb.AutoSize = true;
            this.senior_Rb.Location = new System.Drawing.Point(21, 124);
            this.senior_Rb.Name = "senior_Rb";
            this.senior_Rb.Size = new System.Drawing.Size(55, 17);
            this.senior_Rb.TabIndex = 3;
            this.senior_Rb.TabStop = true;
            this.senior_Rb.Text = "Senior";
            this.senior_Rb.UseVisualStyleBackColor = true;
            // 
            // junor_Rb
            // 
            this.junor_Rb.AutoSize = true;
            this.junor_Rb.Location = new System.Drawing.Point(21, 92);
            this.junor_Rb.Name = "junor_Rb";
            this.junor_Rb.Size = new System.Drawing.Size(53, 17);
            this.junor_Rb.TabIndex = 2;
            this.junor_Rb.TabStop = true;
            this.junor_Rb.Text = "Junior";
            this.junor_Rb.UseVisualStyleBackColor = true;
            // 
            // sophmore_Rb
            // 
            this.sophmore_Rb.AutoSize = true;
            this.sophmore_Rb.Location = new System.Drawing.Point(21, 60);
            this.sophmore_Rb.Name = "sophmore_Rb";
            this.sophmore_Rb.Size = new System.Drawing.Size(73, 17);
            this.sophmore_Rb.TabIndex = 1;
            this.sophmore_Rb.TabStop = true;
            this.sophmore_Rb.Text = "Sophmore";
            this.sophmore_Rb.UseVisualStyleBackColor = true;
            // 
            // freshmen_Rb
            // 
            this.freshmen_Rb.AutoSize = true;
            this.freshmen_Rb.Location = new System.Drawing.Point(21, 28);
            this.freshmen_Rb.Name = "freshmen_Rb";
            this.freshmen_Rb.Size = new System.Drawing.Size(71, 17);
            this.freshmen_Rb.TabIndex = 0;
            this.freshmen_Rb.TabStop = true;
            this.freshmen_Rb.Text = "Freshmen";
            this.freshmen_Rb.UseVisualStyleBackColor = true;
            // 
            // check_Button
            // 
            this.check_Button.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_Button.ForeColor = System.Drawing.SystemColors.Desktop;
            this.check_Button.Location = new System.Drawing.Point(31, 278);
            this.check_Button.Name = "check_Button";
            this.check_Button.Size = new System.Drawing.Size(137, 43);
            this.check_Button.TabIndex = 3;
            this.check_Button.Text = "Check To Register";
            this.check_Button.UseVisualStyleBackColor = true;
            this.check_Button.Click += new System.EventHandler(this.checkButton_Click);
            // 
            // time_Label
            // 
            this.time_Label.AutoSize = true;
            this.time_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time_Label.Location = new System.Drawing.Point(238, 21);
            this.time_Label.Name = "time_Label";
            this.time_Label.Size = new System.Drawing.Size(135, 16);
            this.time_Label.TabIndex = 4;
            this.time_Label.Text = "Registration Time:";
            // 
            // timeDate_Label
            // 
            this.timeDate_Label.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.timeDate_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeDate_Label.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeDate_Label.Location = new System.Drawing.Point(209, 66);
            this.timeDate_Label.Name = "timeDate_Label";
            this.timeDate_Label.Size = new System.Drawing.Size(195, 100);
            this.timeDate_Label.TabIndex = 5;
            this.timeDate_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clear_Button
            // 
            this.clear_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clear_Button.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear_Button.ForeColor = System.Drawing.Color.Maroon;
            this.clear_Button.Location = new System.Drawing.Point(252, 277);
            this.clear_Button.Name = "clear_Button";
            this.clear_Button.Size = new System.Drawing.Size(96, 42);
            this.clear_Button.TabIndex = 6;
            this.clear_Button.Text = "Clear All";
            this.clear_Button.UseVisualStyleBackColor = true;
            this.clear_Button.Click += new System.EventHandler(this.clear_Button_Click);
            // 
            // Program2
            // 
            this.AcceptButton = this.check_Button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.clear_Button;
            this.ClientSize = new System.Drawing.Size(416, 331);
            this.Controls.Add(this.clear_Button);
            this.Controls.Add(this.timeDate_Label);
            this.Controls.Add(this.time_Label);
            this.Controls.Add(this.check_Button);
            this.Controls.Add(this.classGroupBox);
            this.Controls.Add(this.lastName_Tb);
            this.Controls.Add(this.lastName_Label);
            this.DoubleBuffered = true;
            this.Name = "Program2";
            this.Text = "Program 2";
            this.classGroupBox.ResumeLayout(false);
            this.classGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lastName_Label;
        private System.Windows.Forms.TextBox lastName_Tb;
        private System.Windows.Forms.GroupBox classGroupBox;
        private System.Windows.Forms.RadioButton senior_Rb;
        private System.Windows.Forms.RadioButton junor_Rb;
        private System.Windows.Forms.RadioButton sophmore_Rb;
        private System.Windows.Forms.RadioButton freshmen_Rb;
        private System.Windows.Forms.Button check_Button;
        private System.Windows.Forms.Label time_Label;
        private System.Windows.Forms.Label timeDate_Label;
        private System.Windows.Forms.Button clear_Button;
    }
}

