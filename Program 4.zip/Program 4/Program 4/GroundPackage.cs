﻿// C5105
// CIS 199-75
// Program 4
// Due April 25, 2017
// This program describes and calculates packages delivered by Brown Parcel Service. 
// It gives details about the package's origin, destination, length, width, height, and weight.
// It has a details button, send from UofL and send to UofL buttons to represent the costs.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class GroundPackage
    {
        // Constants
        public const int DEFAULT_ORIGINZIP = 40291; // default zip for invalid zip 
        public const int DEFAULT_DESTZIP = 90210; // defualt zip for invalid destination zip
        public const double DEFAULT_PROPERTYVLUE = 1.0; // default value for (Length, Width, Height, and Weight)
        public const double DEFAULT_DIMENSION_VECTOR = .20; // holds (l+w+h)
        public const double DEFAULT_DISTANCE_VECTOR = 05; // holds (ZoneDist + 1)*(Weight)

        // Backing fields 
        private int _originZip;  // origin zip code (not empty)
        private int _destinationZip; // destination zip code (not empty)
        private double _length;     //length (non-negative)
        private double _width;     // width (non-negative)
        private double _height;    // height (non-negative)
        private double _weight;    // weight(non-negative)

        // constructor
        // precondition: all the textboxes have information and are non-negative numbers.
        // postcondition: GroundPackage has been constructed with specified properties. 
        public GroundPackage(int originZip, int destinationzip, double length, double width, double height, double weight)
        {
            //set properties
            OriginZip = originZip;
            DestinationZip = destinationzip;
            Length = length;
            Width = width;
            Height = height;
            Weight = weight;
        }

        double defaultValue = DEFAULT_PROPERTYVLUE;  //default value for length, height, and weight

        // originZip property
        public int OriginZip
        {
            // precondition: None.
            // postcondition: originZip returned, whatever is stored. 
            get { return _originZip; }

            // precondition: value is not empty or all whitespaced
            // postcondition: originZip has been set to specified (trimmed value); tests it.
            set
            {
                if (value > 00000 && value < 99999) // Valid and cannot be a negative number
                    _originZip = value;
                else
                    throw new ArgumentOutOfRangeException("originZip", "originZip must be between 00000 and 99999");
            }
        }

        // DestinationZip property
        public int DestinationZip
        {
            // precondition: none
            // postcondition: DestinationZip returned
            get { return _destinationZip; }

            // precondition: value is not empty or all whitespaced
            // postcondition: destinationZip has been specified (trimmed value); tests it.
            set
            {
                if (value > 00000 && value < 99999) // Valid and cannot be a negative number
                    _destinationZip = value;
                else
                    throw new ArgumentOutOfRangeException("DestinationZip", "DestinationZip cannot be negative!");
            }
        }
        
        // Length property
        public double Length
        {
            // Precondition:  None
            // Postcondition: The Length has been returned
            get { return _length; }

            // Precondition:  value >= 0
            // Postcondition: The Length has been set to the specified value
            set
            {
                if (value >= 00000 && value <= 99999) // Valid and cannot be a negative number 
                    _length = value;
                else
                    _length = defaultValue; //else equals 1.0
            }
        }
        // Width property
        public double Width
        {
            // Precondition:  None
            // Postcondition: The Width has been returned
            get { return _width; }

            // Precondition:  value >= 0
            // Postcondition: The Width has been set to the specified value
            set
            {
                if (value >= 0) // Valid and cannot be a negative number 
                    _width = value;
                else
                    _width = defaultValue; //else equals 1.0            
            }
         }
        // Height property
        public double Height
        {
            // Precondition:  None
            // Postcondition: The Height has been returned
            get { return _height; }

            // Precondition:  value >= 0
            // Postcondition: The Height has been set to the specified value
            set
            {
                if (value >= 0) // Valid and cannot be a negative number
                    _height = value;
                else
                    _height = defaultValue; //else equals 1.0
            }
        }
        // Weight property
        public double Weight
        {
            // Precondition:  None
            // Postcondition: The Weight has been returned
            get { return _weight; }

            // Precondition:  value >= 0
            // Postcondition: The Weight has been set to the specified value
            set
            {
                if (value >= 0) // Valid and cannot be a negative number
                    _weight = value;
                else
                    _weight = defaultValue; //else equals 1.0
            }
        }

        //ZoneDistance property
        public int ZoneDistance
        {
            // PreCondition: None
            // postCondition: the zone distance has been returned
            get { return Math.Abs((OriginZip / 10000) - (DestinationZip / 10000)); }
        }

        // ToString method (Should always be included)
        // Precondition:  None
        // Postcondition: A formatted string representing this CellPhone is returned

        // Precondition: method named CalcCost returns a double and accepts no parameters. 
        // Postcondition: returns the CalcCost 
        public double CalcCost()
        {
            return DEFAULT_DIMENSION_VECTOR*(Length + Width + Height) + DEFAULT_DISTANCE_VECTOR*(ZoneDistance + 1)*(Weight);
        }

        public override string ToString()
        {
            return "Origin Zip: " + OriginZip.ToString("d5") + System.Environment.NewLine +
                "Destination Zip: " + DestinationZip.ToString("d5") + System.Environment.NewLine +
                "Length(in): " + Length.ToString() + System.Environment.NewLine +
                "Width(in): " + Width.ToString() + System.Environment.NewLine +
                "Height(in): " + Height.ToString() + System.Environment.NewLine +
                "Weight(lbs): " + Weight.ToString();
        }
    }
}

