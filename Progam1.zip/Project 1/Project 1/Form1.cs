﻿// C5105
// Program 1
// Due Date: 2/14/2017
// CIS 199-75
// This program is designed to calculate the costing to paint a wall space, 
// by putting in the values for the wall space, coats needed and price per 
// gallon we get an output for total square feet, gallons needed,
// hours of labor, paint cost, labor cost and the total cost.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void quoteButton_Click(object sender, EventArgs e)
        {
            double wallSpace; // square feet of wall space
            int coats; // coats of paint needed
            double paintPrice; // price per gallon of paint
            double totalSqFt; // total square feet to be painted
            double numOfGallons; // number of gallons of paint required
            double laborHours; // hours of labor needed to complete the work
            double paintCost; // total cost of the paint
            double laborCost; // total cost of labor
            double totalCost; // total cost to complete the work
            int sqFtPerGallon = 330; // named constant for square feet
            double hrsOfLaborPerGallon = 6; // named constant for hours of labor
            double laborCostPerHr = 10.50; // named constant for charge per hour

            wallSpace = double.Parse(wallSpaceTb.Text); // gives an output of square feet from the text box
            coats = int.Parse(coatsTb.Text); // gives an output of coats of paint needed
            paintPrice = double.Parse(paintPriceTb.Text); // gives an output for price of paint per gallon

            totalSqFt = wallSpace * coats; // calculates the square feet to be painted
            totalSqFtLabel.Text = totalSqFt.ToString("n1"); // displays the number of square feet to be painted

            numOfGallons = Math.Ceiling(totalSqFt / sqFtPerGallon); // calculates the number of gallons needed 
            gallonsLabel.Text = numOfGallons.ToString("n0"); // displays the number of gallons needed

            laborHours = Math.Round (((totalSqFt / sqFtPerGallon) * hrsOfLaborPerGallon),1); // calculates the hours of labor to get the work done 
            laborHoursLabel.Text = laborHours.ToString("n1"); // dispalys the hours of labor to get the work done

            paintCost = numOfGallons * paintPrice; // calculates the total paint cost
            paintCostLabel.Text = paintCost.ToString("c"); // displays the total paint cost

            laborCost = ((totalSqFt / sqFtPerGallon) * hrsOfLaborPerGallon) * laborCostPerHr; // calculates the total labor cost
            laborCostLabel.Text = laborCost.ToString("c"); // dispalys the total labor cost 

            totalCost = paintCost + laborCost; // calculates the total final cost of everything
            totalCostOutputLabel.Text = totalCost.ToString("c"); // displays the total final cost of everything 

        
        }
    }
}
