﻿namespace Project_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerDataLabel = new System.Windows.Forms.Label();
            this.paintJobLabel = new System.Windows.Forms.Label();
            this.wallSpace = new System.Windows.Forms.Label();
            this.coats = new System.Windows.Forms.Label();
            this.paintPrice = new System.Windows.Forms.Label();
            this.totalSqFt = new System.Windows.Forms.Label();
            this.numOfGallons = new System.Windows.Forms.Label();
            this.laborHours = new System.Windows.Forms.Label();
            this.paintCost = new System.Windows.Forms.Label();
            this.laborCost = new System.Windows.Forms.Label();
            this.totalCost = new System.Windows.Forms.Label();
            this.wallSpaceTb = new System.Windows.Forms.TextBox();
            this.coatsTb = new System.Windows.Forms.TextBox();
            this.paintPriceTb = new System.Windows.Forms.TextBox();
            this.totalSqFtLabel = new System.Windows.Forms.Label();
            this.gallonsLabel = new System.Windows.Forms.Label();
            this.laborHoursLabel = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.totalCostOutputLabel = new System.Windows.Forms.Label();
            this.quoteButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // customerDataLabel
            // 
            this.customerDataLabel.AutoSize = true;
            this.customerDataLabel.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerDataLabel.Location = new System.Drawing.Point(23, 15);
            this.customerDataLabel.Name = "customerDataLabel";
            this.customerDataLabel.Size = new System.Drawing.Size(186, 22);
            this.customerDataLabel.TabIndex = 0;
            this.customerDataLabel.Text = "Enter Customer Data";
            // 
            // paintJobLabel
            // 
            this.paintJobLabel.AutoSize = true;
            this.paintJobLabel.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paintJobLabel.Location = new System.Drawing.Point(315, 15);
            this.paintJobLabel.Name = "paintJobLabel";
            this.paintJobLabel.Size = new System.Drawing.Size(143, 22);
            this.paintJobLabel.TabIndex = 1;
            this.paintJobLabel.Text = "Paint Job Quote";
            // 
            // wallSpace
            // 
            this.wallSpace.AutoSize = true;
            this.wallSpace.Location = new System.Drawing.Point(17, 64);
            this.wallSpace.Name = "wallSpace";
            this.wallSpace.Size = new System.Drawing.Size(130, 13);
            this.wallSpace.TabIndex = 2;
            this.wallSpace.Text = "Square feet of wall space:";
            // 
            // coats
            // 
            this.coats.AutoSize = true;
            this.coats.Location = new System.Drawing.Point(29, 93);
            this.coats.Name = "coats";
            this.coats.Size = new System.Drawing.Size(115, 13);
            this.coats.TabIndex = 3;
            this.coats.Text = "Coats of paint to apply:";
            // 
            // paintPrice
            // 
            this.paintPrice.AutoSize = true;
            this.paintPrice.Location = new System.Drawing.Point(61, 123);
            this.paintPrice.Name = "paintPrice";
            this.paintPrice.Size = new System.Drawing.Size(83, 13);
            this.paintPrice.TabIndex = 4;
            this.paintPrice.Text = "Price per gallon:";
            // 
            // totalSqFt
            // 
            this.totalSqFt.AutoSize = true;
            this.totalSqFt.Location = new System.Drawing.Point(280, 64);
            this.totalSqFt.Name = "totalSqFt";
            this.totalSqFt.Size = new System.Drawing.Size(90, 13);
            this.totalSqFt.TabIndex = 5;
            this.totalSqFt.Text = "Total square feet:";
            // 
            // numOfGallons
            // 
            this.numOfGallons.AutoSize = true;
            this.numOfGallons.Location = new System.Drawing.Point(286, 93);
            this.numOfGallons.Name = "numOfGallons";
            this.numOfGallons.Size = new System.Drawing.Size(84, 13);
            this.numOfGallons.TabIndex = 6;
            this.numOfGallons.Text = "Gallons needed:";
            // 
            // laborHours
            // 
            this.laborHours.AutoSize = true;
            this.laborHours.Location = new System.Drawing.Point(294, 123);
            this.laborHours.Name = "laborHours";
            this.laborHours.Size = new System.Drawing.Size(76, 13);
            this.laborHours.TabIndex = 7;
            this.laborHours.Text = "Hours of labor:";
            // 
            // paintCost
            // 
            this.paintCost.AutoSize = true;
            this.paintCost.Location = new System.Drawing.Point(313, 173);
            this.paintCost.Name = "paintCost";
            this.paintCost.Size = new System.Drawing.Size(57, 13);
            this.paintCost.TabIndex = 8;
            this.paintCost.Text = "Paint cost:";
            // 
            // laborCost
            // 
            this.laborCost.AutoSize = true;
            this.laborCost.Location = new System.Drawing.Point(310, 198);
            this.laborCost.Name = "laborCost";
            this.laborCost.Size = new System.Drawing.Size(60, 13);
            this.laborCost.TabIndex = 9;
            this.laborCost.Text = "Labor cost:";
            // 
            // totalCost
            // 
            this.totalCost.AutoSize = true;
            this.totalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCost.Location = new System.Drawing.Point(289, 220);
            this.totalCost.Name = "totalCost";
            this.totalCost.Size = new System.Drawing.Size(81, 16);
            this.totalCost.TabIndex = 10;
            this.totalCost.Text = "Total cost:";
            // 
            // wallSpaceTb
            // 
            this.wallSpaceTb.Location = new System.Drawing.Point(153, 61);
            this.wallSpaceTb.Name = "wallSpaceTb";
            this.wallSpaceTb.Size = new System.Drawing.Size(89, 20);
            this.wallSpaceTb.TabIndex = 11;
            // 
            // coatsTb
            // 
            this.coatsTb.Location = new System.Drawing.Point(153, 90);
            this.coatsTb.Name = "coatsTb";
            this.coatsTb.Size = new System.Drawing.Size(89, 20);
            this.coatsTb.TabIndex = 12;
            // 
            // paintPriceTb
            // 
            this.paintPriceTb.Location = new System.Drawing.Point(153, 116);
            this.paintPriceTb.Name = "paintPriceTb";
            this.paintPriceTb.Size = new System.Drawing.Size(89, 20);
            this.paintPriceTb.TabIndex = 13;
            // 
            // totalSqFtLabel
            // 
            this.totalSqFtLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSqFtLabel.Location = new System.Drawing.Point(378, 61);
            this.totalSqFtLabel.Name = "totalSqFtLabel";
            this.totalSqFtLabel.Size = new System.Drawing.Size(93, 20);
            this.totalSqFtLabel.TabIndex = 14;
            // 
            // gallonsLabel
            // 
            this.gallonsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsLabel.Location = new System.Drawing.Point(378, 92);
            this.gallonsLabel.Name = "gallonsLabel";
            this.gallonsLabel.Size = new System.Drawing.Size(93, 20);
            this.gallonsLabel.TabIndex = 15;
            // 
            // laborHoursLabel
            // 
            this.laborHoursLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborHoursLabel.Location = new System.Drawing.Point(378, 122);
            this.laborHoursLabel.Name = "laborHoursLabel";
            this.laborHoursLabel.Size = new System.Drawing.Size(93, 20);
            this.laborHoursLabel.TabIndex = 16;
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintCostLabel.Location = new System.Drawing.Point(378, 166);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(93, 20);
            this.paintCostLabel.TabIndex = 17;
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborCostLabel.Location = new System.Drawing.Point(378, 191);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(93, 20);
            this.laborCostLabel.TabIndex = 18;
            // 
            // totalCostOutputLabel
            // 
            this.totalCostOutputLabel.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.totalCostOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOutputLabel.Location = new System.Drawing.Point(378, 220);
            this.totalCostOutputLabel.Name = "totalCostOutputLabel";
            this.totalCostOutputLabel.Size = new System.Drawing.Size(93, 20);
            this.totalCostOutputLabel.TabIndex = 19;
            // 
            // quoteButton
            // 
            this.quoteButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quoteButton.Location = new System.Drawing.Point(64, 177);
            this.quoteButton.Name = "quoteButton";
            this.quoteButton.Size = new System.Drawing.Size(145, 34);
            this.quoteButton.TabIndex = 20;
            this.quoteButton.Text = "Generate Quote";
            this.quoteButton.UseVisualStyleBackColor = true;
            this.quoteButton.Click += new System.EventHandler(this.quoteButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.quoteButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 280);
            this.Controls.Add(this.quoteButton);
            this.Controls.Add(this.totalCostOutputLabel);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.laborHoursLabel);
            this.Controls.Add(this.gallonsLabel);
            this.Controls.Add(this.totalSqFtLabel);
            this.Controls.Add(this.paintPriceTb);
            this.Controls.Add(this.coatsTb);
            this.Controls.Add(this.wallSpaceTb);
            this.Controls.Add(this.totalCost);
            this.Controls.Add(this.laborCost);
            this.Controls.Add(this.paintCost);
            this.Controls.Add(this.laborHours);
            this.Controls.Add(this.numOfGallons);
            this.Controls.Add(this.totalSqFt);
            this.Controls.Add(this.paintPrice);
            this.Controls.Add(this.coats);
            this.Controls.Add(this.wallSpace);
            this.Controls.Add(this.paintJobLabel);
            this.Controls.Add(this.customerDataLabel);
            this.Name = "Form1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label customerDataLabel;
        private System.Windows.Forms.Label paintJobLabel;
        private System.Windows.Forms.Label wallSpace;
        private System.Windows.Forms.Label coats;
        private System.Windows.Forms.Label paintPrice;
        private System.Windows.Forms.Label totalSqFt;
        private System.Windows.Forms.Label numOfGallons;
        private System.Windows.Forms.Label laborHours;
        private System.Windows.Forms.Label paintCost;
        private System.Windows.Forms.Label laborCost;
        private System.Windows.Forms.Label totalCost;
        private System.Windows.Forms.TextBox wallSpaceTb;
        private System.Windows.Forms.TextBox coatsTb;
        private System.Windows.Forms.TextBox paintPriceTb;
        private System.Windows.Forms.Label totalSqFtLabel;
        private System.Windows.Forms.Label gallonsLabel;
        private System.Windows.Forms.Label laborHoursLabel;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label totalCostOutputLabel;
        private System.Windows.Forms.Button quoteButton;
    }
}

